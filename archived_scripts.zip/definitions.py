"""
Definitions for Synthetic Data Outcome Prediction Pipeline
=========================================================

This module contains all class definitions, constants, and utility functions
used in the Gaussian-Copula based synthetic data prediction pipeline.
"""

import pandas as pd
import numpy as np
from typing import Dict, List, Tuple, Optional, Any, Union
from dataclasses import dataclass
from enum import Enum
import logging
from pathlib import Path

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class ModelType(Enum):
    """Enumeration of supported surrogate model types."""
    RANDOM_FOREST = "random_forest"
    BAYESIAN_NN = "bayesian_nn"
    GRADIENT_BOOSTING = "gradient_boosting"

class EncodingType(Enum):
    """Enumeration of supported encoding types for categorical variables."""
    LABEL_ENCODING = "label"
    ONE_HOT_ENCODING = "onehot"
    TARGET_ENCODING = "target"

@dataclass
class PipelineConfig:
    """Configuration class for the synthetic data prediction pipeline."""
    
    # Data paths
    historical_data_path: str = "data/historical_data.csv"
    prediction_input_path: str = "data/prediction_input.csv"
    output_path: str = "output/synthetic_predictions.csv"
    
    # Model parameters
    surrogate_model_type: ModelType = ModelType.RANDOM_FOREST
    encoding_type: EncodingType = EncodingType.LABEL_ENCODING
    
    # Gaussian Copula parameters
    copula_random_state: int = 42
    n_synthetic_samples: int = 1000
    
    # Model hyperparameters
    rf_n_estimators: int = 100
    rf_max_depth: Optional[int] = None
    rf_random_state: int = 42
    
    # Bayesian NN parameters (if using)
    nn_hidden_layers: List[int] = None
    nn_epochs: int = 100
    nn_batch_size: int = 32
    
    # Target columns
    target_columns: List[str] = None
    
    # Categorical columns
    categorical_columns: List[str] = None
    
    # ID column (to preserve during processing)
    id_column: Optional[str] = None
    
    # Validation parameters
    test_size: float = 0.2
    validation_random_state: int = 42
    
    def __post_init__(self):
        """Initialize default values after dataclass creation."""
        if self.target_columns is None:
            self.target_columns = ['yield', 'burden']
        if self.categorical_columns is None:
            self.categorical_columns = ['part_name', 'condition']
        if self.nn_hidden_layers is None:
            self.nn_hidden_layers = [64, 32, 16]

class DataValidator:
    """Utility class for data validation and quality checks."""
    
    @staticmethod
    def validate_dataframe(df: pd.DataFrame, required_columns: List[str]) -> bool:
        """
        Validate that dataframe contains all required columns.
        
        Args:
            df: DataFrame to validate
            required_columns: List of required column names
            
        Returns:
            bool: True if valid, False otherwise
        """
        missing_columns = set(required_columns) - set(df.columns)
        if missing_columns:
            logger.error(f"Missing required columns: {missing_columns}")
            return False
        return True
    
    @staticmethod
    def check_data_quality(df: pd.DataFrame) -> Dict[str, Any]:
        """
        Perform comprehensive data quality checks.
        
        Args:
            df: DataFrame to check
            
        Returns:
            Dict containing quality metrics
        """
        quality_report = {
            'total_rows': len(df),
            'total_columns': len(df.columns),
            'missing_values': df.isnull().sum().to_dict(),
            'duplicate_rows': df.duplicated().sum(),
            'data_types': df.dtypes.to_dict(),
            'numeric_columns': df.select_dtypes(include=[np.number]).columns.tolist(),
            'categorical_columns': df.select_dtypes(include=['object']).columns.tolist()
        }
        
        # Check for outliers in numeric columns
        numeric_cols = quality_report['numeric_columns']
        outliers = {}
        for col in numeric_cols:
            Q1 = df[col].quantile(0.25)
            Q3 = df[col].quantile(0.75)
            IQR = Q3 - Q1
            lower_bound = Q1 - 1.5 * IQR
            upper_bound = Q3 + 1.5 * IQR
            outliers[col] = len(df[(df[col] < lower_bound) | (df[col] > upper_bound)])
        
        quality_report['outliers'] = outliers
        
        logger.info(f"Data quality report: {quality_report}")
        return quality_report

class DataPreprocessor:
    """Handles data preprocessing including encoding and scaling."""
    
    def __init__(self, config: PipelineConfig):
        self.config = config
        self.encoders = {}
        self.scalers = {}
        self.is_fitted = False
        self.id_values = None
    
    def fit_transform(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Fit preprocessors and transform the data.
        
        Args:
            df: Input DataFrame
            
        Returns:
            Transformed DataFrame
        """
        from sklearn.preprocessing import LabelEncoder, StandardScaler
        from sklearn.preprocessing import OneHotEncoder
        
        df_processed = df.copy()
        
        # Store ID column if specified
        if self.config.id_column and self.config.id_column in df_processed.columns:
            self.id_values = df_processed[self.config.id_column].copy()
            df_processed = df_processed.drop(self.config.id_column, axis=1)
        
        # Handle categorical encoding
        if self.config.encoding_type == EncodingType.LABEL_ENCODING:
            for col in self.config.categorical_columns:
                if col in df_processed.columns:
                    le = LabelEncoder()
                    df_processed[col] = le.fit_transform(df_processed[col].astype(str))
                    self.encoders[col] = le
        
        elif self.config.encoding_type == EncodingType.ONE_HOT_ENCODING:
            for col in self.config.categorical_columns:
                if col in df_processed.columns:
                    ohe = OneHotEncoder(sparse_output=False, handle_unknown='ignore')
                    encoded = ohe.fit_transform(df_processed[[col]])
                    encoded_df = pd.DataFrame(
                        encoded, 
                        columns=[f"{col}_{cat}" for cat in ohe.categories_[0]],
                        index=df_processed.index
                    )
                    df_processed = pd.concat([df_processed.drop(col, axis=1), encoded_df], axis=1)
                    self.encoders[col] = ohe
        
        # Scale numeric features
        numeric_cols = df_processed.select_dtypes(include=[np.number]).columns.tolist()
        # Remove target columns from scaling
        feature_cols = [col for col in numeric_cols if col not in self.config.target_columns]
        
        if feature_cols:
            scaler = StandardScaler()
            df_processed[feature_cols] = scaler.fit_transform(df_processed[feature_cols])
            self.scalers['features'] = scaler
        
        self.is_fitted = True
        logger.info("Data preprocessing completed successfully")
        return df_processed
    
    def transform(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Transform new data using fitted preprocessors.
        
        Args:
            df: Input DataFrame
            
        Returns:
            Transformed DataFrame
        """
        if not self.is_fitted:
            raise ValueError("Preprocessor must be fitted before transform")
        
        df_processed = df.copy()
        
        # Store ID column if specified
        if self.config.id_column and self.config.id_column in df_processed.columns:
            self.id_values = df_processed[self.config.id_column].copy()
            df_processed = df_processed.drop(self.config.id_column, axis=1)
        
        # Apply categorical encoding
        if self.config.encoding_type == EncodingType.LABEL_ENCODING:
            for col in self.config.categorical_columns:
                if col in df_processed.columns and col in self.encoders:
                    # Handle unseen categories
                    unique_values = set(df_processed[col].astype(str))
                    known_values = set(self.encoders[col].classes_)
                    unseen_values = unique_values - known_values
                    
                    if unseen_values:
                        logger.warning(f"Unseen categories in {col}: {unseen_values}")
                        # Map unseen values to the first known category
                        df_processed[col] = df_processed[col].astype(str).replace(
                            list(unseen_values), 
                            [self.encoders[col].classes_[0]] * len(unseen_values)
                        )
                    
                    df_processed[col] = self.encoders[col].transform(df_processed[col].astype(str))
        
        elif self.config.encoding_type == EncodingType.ONE_HOT_ENCODING:
            for col in self.config.categorical_columns:
                if col in df_processed.columns and col in self.encoders:
                    encoded = self.encoders[col].transform(df_processed[[col]])
                    encoded_df = pd.DataFrame(
                        encoded, 
                        columns=[f"{col}_{cat}" for cat in self.encoders[col].categories_[0]],
                        index=df_processed.index
                    )
                    df_processed = pd.concat([df_processed.drop(col, axis=1), encoded_df], axis=1)
        
        # Scale numeric features
        if 'features' in self.scalers:
            numeric_cols = df_processed.select_dtypes(include=[np.number]).columns.tolist()
            feature_cols = [col for col in numeric_cols if col not in self.config.target_columns]
            feature_cols = [col for col in feature_cols if col in df_processed.columns]
            
            if feature_cols:
                df_processed[feature_cols] = self.scalers['features'].transform(df_processed[feature_cols])
        
        return df_processed
    
    def inverse_transform_categorical(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Inverse transform categorical columns back to original values.
        
        Args:
            df: DataFrame with encoded categorical columns
            
        Returns:
            DataFrame with decoded categorical columns
        """
        df_decoded = df.copy()
        
        if self.config.encoding_type == EncodingType.LABEL_ENCODING:
            for col in self.config.categorical_columns:
                if col in df_decoded.columns and col in self.encoders:
                    df_decoded[col] = self.encoders[col].inverse_transform(df_decoded[col].astype(int))
        
        elif self.config.encoding_type == EncodingType.ONE_HOT_ENCODING:
            for col in self.config.categorical_columns:
                if col in self.encoders:
                    # Find encoded columns for this categorical variable
                    encoded_cols = [c for c in df_decoded.columns if c.startswith(f"{col}_")]
                    if encoded_cols:
                        # Reconstruct original categorical values
                        encoded_values = df_decoded[encoded_cols].values
                        original_values = self.encoders[col].inverse_transform(encoded_values)
                        df_decoded[col] = original_values
                        # Drop encoded columns
                        df_decoded = df_decoded.drop(encoded_cols, axis=1)
        
        # Restore ID column if it was stored
        if self.id_values is not None and self.config.id_column:
            df_decoded[self.config.id_column] = self.id_values.reset_index(drop=True)
        
        return df_decoded

class ModelTrainer:
    """Handles training of surrogate models for outcome prediction."""
    
    def __init__(self, config: PipelineConfig):
        self.config = config
        self.model = None
        self.is_fitted = False
    
    def train(self, X: pd.DataFrame, y: pd.DataFrame) -> Dict[str, float]:
        """
        Train the surrogate model.
        
        Args:
            X: Feature DataFrame
            y: Target DataFrame
            
        Returns:
            Dictionary with training metrics
        """
        from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
        from sklearn.model_selection import train_test_split
        from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error
        
        # Split data for validation
        X_train, X_val, y_train, y_val = train_test_split(
            X, y, 
            test_size=self.config.test_size,
            random_state=self.config.validation_random_state
        )
        
        # Initialize model based on configuration
        if self.config.surrogate_model_type == ModelType.RANDOM_FOREST:
            self.model = RandomForestRegressor(
                n_estimators=self.config.rf_n_estimators,
                max_depth=self.config.rf_max_depth,
                random_state=self.config.rf_random_state,
                n_jobs=-1
            )
        elif self.config.surrogate_model_type == ModelType.GRADIENT_BOOSTING:
            self.model = GradientBoostingRegressor(
                n_estimators=self.config.rf_n_estimators,
                max_depth=self.config.rf_max_depth,
                random_state=self.config.rf_random_state
            )
        else:
            raise ValueError(f"Unsupported model type: {self.config.surrogate_model_type}")
        
        # Train model
        logger.info(f"Training {self.config.surrogate_model_type.value} model...")
        self.model.fit(X_train, y_train)
        
        # Validate model
        y_pred = self.model.predict(X_val)
        
        # Calculate metrics
        metrics = {}
        for i, target_col in enumerate(self.config.target_columns):
            if y_val.shape[1] > 1:
                y_true_col = y_val.iloc[:, i]
                y_pred_col = y_pred[:, i]
            else:
                y_true_col = y_val.iloc[:, 0]
                y_pred_col = y_pred
            
            metrics[f'{target_col}_mse'] = mean_squared_error(y_true_col, y_pred_col)
            metrics[f'{target_col}_rmse'] = np.sqrt(metrics[f'{target_col}_mse'])
            metrics[f'{target_col}_mae'] = mean_absolute_error(y_true_col, y_pred_col)
            metrics[f'{target_col}_r2'] = r2_score(y_true_col, y_pred_col)
        
        self.is_fitted = True
        logger.info(f"Model training completed. Metrics: {metrics}")
        return metrics
    
    def predict(self, X: pd.DataFrame) -> np.ndarray:
        """
        Make predictions using the trained model.
        
        Args:
            X: Feature DataFrame
            
        Returns:
            Predictions array
        """
        if not self.is_fitted:
            raise ValueError("Model must be trained before making predictions")
        
        return self.model.predict(X)

class OutputManager:
    """Handles output formatting and saving."""
    
    @staticmethod
    def save_predictions(
        predictions: pd.DataFrame, 
        output_path: str,
        include_metadata: bool = True
    ) -> None:
        """
        Save predictions to CSV file.
        
        Args:
            predictions: DataFrame with predictions
            output_path: Path to save the output file
            include_metadata: Whether to include metadata in the output
        """
        # Create output directory if it doesn't exist
        output_dir = Path(output_path).parent
        output_dir.mkdir(parents=True, exist_ok=True)
        
        # Save predictions
        predictions.to_csv(output_path, index=False)
        
        # Save metadata if requested
        if include_metadata:
            metadata = {
                'timestamp': pd.Timestamp.now().isoformat(),
                'total_predictions': len(predictions),
                'columns': list(predictions.columns),
                'summary_stats': predictions.describe().to_dict()
            }
            
            metadata_path = output_path.replace('.csv', '_metadata.json')
            import json
            with open(metadata_path, 'w') as f:
                json.dump(metadata, f, indent=2, default=str)
        
        logger.info(f"Predictions saved to {output_path}")
    
    @staticmethod
    def generate_report(
        metrics: Dict[str, float],
        config: PipelineConfig,
        output_dir: str = "output"
    ) -> None:
        """
        Generate a comprehensive report of the pipeline execution.
        
        Args:
            metrics: Dictionary of model performance metrics
            config: Pipeline configuration
            output_dir: Directory to save the report
        """
        import json
        from datetime import datetime
        
        report = {
            'execution_timestamp': datetime.now().isoformat(),
            'pipeline_config': {
                'surrogate_model_type': config.surrogate_model_type.value,
                'encoding_type': config.encoding_type.value,
                'n_synthetic_samples': config.n_synthetic_samples,
                'target_columns': config.target_columns,
                'categorical_columns': config.categorical_columns
            },
            'model_performance': metrics,
            'data_paths': {
                'historical_data': config.historical_data_path,
                'prediction_input': config.prediction_input_path,
                'output': config.output_path
            }
        }
        
        # Create output directory
        Path(output_dir).mkdir(parents=True, exist_ok=True)
        
        # Save report
        report_path = Path(output_dir) / 'pipeline_report.json'
        with open(report_path, 'w') as f:
            json.dump(report, f, indent=2, default=str)
        
        logger.info(f"Pipeline report saved to {report_path}")

# Constants
DEFAULT_CONFIG = PipelineConfig()
SUPPORTED_FILE_FORMATS = ['.csv', '.xlsx', '.json']
MIN_SAMPLE_SIZE = 10
MAX_SAMPLE_SIZE = 100000

# Utility functions
def load_data(file_path: str) -> pd.DataFrame:
    """
    Load data from various file formats.
    
    Args:
        file_path: Path to the data file
        
    Returns:
        Loaded DataFrame
    """
    file_path = Path(file_path)
    
    if not file_path.exists():
        raise FileNotFoundError(f"Data file not found: {file_path}")
    
    if file_path.suffix.lower() == '.csv':
        return pd.read_csv(file_path)
    elif file_path.suffix.lower() in ['.xlsx', '.xls']:
        return pd.read_excel(file_path)
    elif file_path.suffix.lower() == '.json':
        return pd.read_json(file_path)
    else:
        raise ValueError(f"Unsupported file format: {file_path.suffix}")

def setup_logging(log_level: str = "INFO", log_file: Optional[str] = None) -> None:
    """
    Setup logging configuration.
    
    Args:
        log_level: Logging level
        log_file: Optional log file path
    """
    level = getattr(logging, log_level.upper())
    
    if log_file:
        logging.basicConfig(
            level=level,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(log_file),
                logging.StreamHandler()
            ]
        )
    else:
        logging.basicConfig(
            level=level,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
