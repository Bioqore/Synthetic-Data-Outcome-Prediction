#!/usr/bin/env python3
"""
Create Plasmid Sample Data
=========================

This script creates sample datasets for the plasmid optimization project.
"""

import pandas as pd
import numpy as np
from pathlib import Path
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def create_plasmid_sample_data():
    """Create sample datasets for the plasmid optimization project."""
    
    # Define output paths
    output_dir = Path("/Users/joshuahinckley/Library/CloudStorage/GoogleDrive-josh@bioqore.ai/Shared drives/Bioqore/Product Development/Plasmid Optimization")
    training_path = output_dir / "synthetic_plasmid_training_set.csv"
    prediction_path = output_dir / "plasmid_dataframe.csv"
    
    # Create output directory if it doesn't exist
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # Define sample data parameters
    np.random.seed(42)
    n_training = 100
    n_prediction = 100
    
    # Define plasmid components
    promoters = ['pBAD', 'T7', 'pLac', 'pTet', 'pTrc']
    oris = ['ColE1', 'pUC', 'pSC101', 'p15A', 'pBR322']
    antibiotics = ['AmpR', 'KanR', 'CmR', 'TetR', 'ZeoR']
    rbs_strengths = ['Strong', 'Medium', 'Weak']
    pois = ['lacZ', 'gfp', 'cas9', 'rfp', 'luxA']
    terminators = ['rrnB', 'T1', 'T7', 'lambda', 'Synthetic']
    orf_lengths = [300, 400, 500, 600, 800]
    
    # Generate training data
    training_data = pd.DataFrame({
        'promoter': np.random.choice(promoters, n_training),
        'ori': np.random.choice(oris, n_training),
        'antibiotic': np.random.choice(antibiotics, n_training),
        'rbs': np.random.choice(rbs_strengths, n_training),
        'poi': np.random.choice(pois, n_training),
        'terminator': np.random.choice(terminators, n_training),
        'orf': np.random.choice(orf_lengths, n_training)
    })
    
    # Add outcome variables with dependencies on features
    # Base values
    yield_base = 30
    burden_base = 40
    
    # Promoter effects
    promoter_yield = {'pBAD': -5, 'T7': 10, 'pLac': 0, 'pTet': -2, 'pTrc': 5}
    promoter_burden = {'pBAD': 5, 'T7': 10, 'pLac': 0, 'pTet': -5, 'pTrc': 8}
    
    # Ori effects
    ori_yield = {'ColE1': 0, 'pUC': 5, 'pSC101': -5, 'p15A': -2, 'pBR322': 2}
    ori_burden = {'ColE1': 5, 'pUC': 10, 'pSC101': -5, 'p15A': 0, 'pBR322': 2}
    
    # RBS effects
    rbs_yield = {'Strong': 5, 'Medium': 0, 'Weak': -5}
    rbs_burden = {'Strong': 8, 'Medium': 0, 'Weak': -8}
    
    # Calculate yield and burden scores
    yield_scores = []
    burden_scores = []
    
    for _, row in training_data.iterrows():
        # Base yield with feature effects
        yield_score = yield_base
        yield_score += promoter_yield[row['promoter']]
        yield_score += ori_yield[row['ori']]
        yield_score += rbs_yield[row['rbs']]
        yield_score += (row['orf'] - 500) * 0.02  # Small effect from ORF length
        
        # Add some interactions
        if row['promoter'] == 'T7' and row['rbs'] == 'Strong':
            yield_score += 5  # Synergistic effect
        
        if row['poi'] == 'cas9':
            yield_score += 3  # cas9 has higher yield
        
        # Add some noise
        yield_score += np.random.normal(0, 3)
        
        # Base burden with feature effects
        burden_score = burden_base
        burden_score += promoter_burden[row['promoter']]
        burden_score += ori_burden[row['ori']]
        burden_score += rbs_burden[row['rbs']]
        burden_score += (row['orf'] - 500) * 0.03  # Larger effect from ORF length
        
        # Add some interactions
        if row['promoter'] == 'T7' and row['ori'] == 'pUC':
            burden_score += 8  # High burden combination
        
        if row['poi'] == 'cas9':
            burden_score += 5  # cas9 has higher burden
        
        # Add some noise
        burden_score += np.random.normal(0, 4)
        
        # Ensure positive values
        yield_scores.append(max(5, yield_score))
        burden_scores.append(max(5, burden_score))
    
    training_data['yield_score'] = yield_scores
    training_data['burden_score'] = burden_scores
    
    # Generate prediction input data
    prediction_data = pd.DataFrame({
        'promoter': np.random.choice(promoters, n_prediction),
        'ori': np.random.choice(oris, n_prediction),
        'antibiotic': np.random.choice(antibiotics, n_prediction),
        'rbs': np.random.choice(rbs_strengths, n_prediction),
        'poi': np.random.choice(pois, n_prediction),
        'terminator': np.random.choice(terminators, n_prediction),
        'orf': np.random.choice(orf_lengths, n_prediction),
        'plasmid_id': [f'bq{i+1:05d}' for i in range(n_prediction)]
    })
    
    # Save datasets
    training_data.to_csv(training_path, index=False)
    prediction_data.to_csv(prediction_path, index=False)
    
    logger.info(f"Sample datasets created:")
    logger.info(f"Training data: {len(training_data)} samples saved to {training_path}")
    logger.info(f"Prediction input: {len(prediction_data)} samples saved to {prediction_path}")

if __name__ == "__main__":
    create_plasmid_sample_data() 