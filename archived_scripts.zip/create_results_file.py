#!/usr/bin/env python3
"""
Create Results File Script
==========================

This script creates a results CSV file that combines the input data with prediction results.
The output file will be named [input file name]_results.csv.
"""

import os
import pandas as pd
import argparse
from pathlib import Path
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def create_results_file(input_path: str, predictions_path: str, output_path: str = None) -> str:
    """
    Create a results file by combining input data with prediction results.
    
    Args:
        input_path: Path to the input CSV file
        predictions_path: Path to the predictions CSV file
        output_path: Path for the output results file (optional)
        
    Returns:
        Path to the created results file
    """
    logger.info(f"Loading input file: {input_path}")
    input_df = pd.read_csv(input_path)
    
    logger.info(f"Loading predictions file: {predictions_path}")
    predictions_df = pd.read_csv(predictions_path)
    
    # If output path is not specified, create it based on input file name
    if output_path is None:
        input_file_name = Path(input_path).stem
        output_dir = Path(input_path).parent
        output_path = output_dir / f"{input_file_name}_results.csv"
    
    # Extract only the prediction columns (yield_score and burden_score)
    prediction_columns = ['yield_score', 'burden_score']
    
    # Check if predictions file contains the required columns
    missing_columns = [col for col in prediction_columns if col not in predictions_df.columns]
    if missing_columns:
        raise ValueError(f"Predictions file is missing required columns: {missing_columns}")
    
    # If plasmid_id column exists in both dataframes, use it to merge
    if 'plasmid_id' in input_df.columns and 'plasmid_id' in predictions_df.columns:
        logger.info("Merging based on plasmid_id column")
        results_df = input_df.merge(
            predictions_df[['plasmid_id'] + prediction_columns],
            on='plasmid_id',
            how='left'
        )
    else:
        # If no plasmid_id, assume the rows are in the same order
        logger.warning("No plasmid_id column found. Assuming rows are in the same order.")
        results_df = input_df.copy()
        for col in prediction_columns:
            results_df[col] = predictions_df[col].values[:len(input_df)]
    
    # Save the results
    logger.info(f"Saving results to: {output_path}")
    results_df.to_csv(output_path, index=False)
    
    return str(output_path)

def main():
    """Main function to parse arguments and create results file."""
    parser = argparse.ArgumentParser(
        description="Create a results CSV file by combining input data with prediction results"
    )
    
    parser.add_argument(
        "--input",
        type=str,
        required=True,
        help="Path to the input CSV file"
    )
    
    parser.add_argument(
        "--predictions",
        type=str,
        required=True,
        help="Path to the predictions CSV file"
    )
    
    parser.add_argument(
        "--output",
        type=str,
        help="Path for the output results file (optional)"
    )
    
    args = parser.parse_args()
    
    try:
        output_path = create_results_file(args.input, args.predictions, args.output)
        logger.info(f"Results file created successfully: {output_path}")
        return 0
    except Exception as e:
        logger.error(f"Error creating results file: {str(e)}")
        return 1

if __name__ == "__main__":
    exit(main()) 