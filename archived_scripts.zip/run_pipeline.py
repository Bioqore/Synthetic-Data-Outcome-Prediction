#!/usr/bin/env python3
"""
Run Script for Synthetic Data Outcome Prediction Pipeline
========================================================

This script serves as the main entry point for running the synthetic data
prediction pipeline. It provides command-line interface and configuration
options for different execution modes.

Usage:
    python run_pipeline.py [options]

Examples:
    # Run with default configuration
    python run_pipeline.py

    # Run with custom configuration
    python run_pipeline.py --config custom_config.json

    # Run with synthetic data augmentation
    python run_pipeline.py --augment

    # Validate pipeline setup only
    python run_pipeline.py --validate-only

    # Create sample data
    python run_pipeline.py --create-sample-data
"""

import argparse
import json
import sys
from pathlib import Path
from typing import Dict, Any, Optional

# Import pipeline components
from main_pipeline import SyntheticDataPipeline, create_sample_data
from definitions import PipelineConfig, ModelType, EncodingType, setup_logging, logger

def load_config_from_file(config_path: str) -> Dict[str, Any]:
    """
    Load configuration from JSON file.
    
    Args:
        config_path: Path to configuration JSON file
        
    Returns:
        Configuration dictionary
    """
    try:
        with open(config_path, 'r') as f:
            config_dict = json.load(f)
        logger.info(f"Configuration loaded from {config_path}")
        return config_dict
    except Exception as e:
        logger.error(f"Error loading configuration from {config_path}: {str(e)}")
        raise

def create_config_from_args(args: argparse.Namespace) -> PipelineConfig:
    """
    Create pipeline configuration from command line arguments.
    
    Args:
        args: Parsed command line arguments
        
    Returns:
        PipelineConfig object
    """
    config_dict = {}
    
    # Load from file if specified
    if args.config:
        config_dict = load_config_from_file(args.config)
    
    # Override with command line arguments
    if args.historical_data:
        config_dict['historical_data_path'] = args.historical_data
    if args.prediction_input:
        config_dict['prediction_input_path'] = args.prediction_input
    if args.output:
        config_dict['output_path'] = args.output
    if args.model_type:
        config_dict['surrogate_model_type'] = args.model_type
    if args.encoding_type:
        config_dict['encoding_type'] = args.encoding_type
    if args.n_samples:
        config_dict['n_synthetic_samples'] = args.n_samples
    if args.target_columns:
        config_dict['target_columns'] = args.target_columns
    if args.categorical_columns:
        config_dict['categorical_columns'] = args.categorical_columns
    
    # Create configuration object
    if config_dict:
        # Create config with custom values
        config = PipelineConfig()
        for key, value in config_dict.items():
            if hasattr(config, key):
                # Handle enum types
                if key == 'surrogate_model_type' and isinstance(value, str):
                    config.surrogate_model_type = ModelType(value)
                elif key == 'encoding_type' and isinstance(value, str):
                    config.encoding_type = EncodingType(value)
                else:
                    setattr(config, key, value)
        return config
    else:
        # Use default configuration
        return PipelineConfig()

def save_sample_config(output_path: str = "sample_config.json") -> None:
    """
    Save a sample configuration file for reference.
    
    Args:
        output_path: Path to save the sample configuration
    """
    sample_config = {
        "historical_data_path": "data/historical_data.csv",
        "prediction_input_path": "data/prediction_input.csv",
        "output_path": "output/synthetic_predictions.csv",
        "surrogate_model_type": "random_forest",
        "encoding_type": "label",
        "n_synthetic_samples": 1000,
        "target_columns": ["yield", "burden"],
        "categorical_columns": ["part_name", "condition"],
        "rf_n_estimators": 100,
        "rf_max_depth": null,
        "test_size": 0.2,
        "validation_random_state": 42
    }
    
    with open(output_path, 'w') as f:
        json.dump(sample_config, f, indent=2)
    
    logger.info(f"Sample configuration saved to {output_path}")

def main():
    """Main execution function."""
    parser = argparse.ArgumentParser(
        description="Synthetic Data Outcome Prediction Pipeline",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s                                    # Run with default settings
  %(prog)s --augment                          # Run with synthetic augmentation
  %(prog)s --config my_config.json           # Run with custom config
  %(prog)s --validate-only                   # Validate setup only
  %(prog)s --create-sample-data               # Create sample datasets
  %(prog)s --model-type gradient_boosting     # Use gradient boosting model
  %(prog)s --encoding-type onehot             # Use one-hot encoding
        """
    )
    
    # Data paths
    parser.add_argument(
        '--historical-data',
        type=str,
        help='Path to historical data CSV file'
    )
    parser.add_argument(
        '--prediction-input',
        type=str,
        help='Path to prediction input CSV file'
    )
    parser.add_argument(
        '--output',
        type=str,
        help='Path for output predictions CSV file'
    )
    
    # Configuration
    parser.add_argument(
        '--config',
        type=str,
        help='Path to configuration JSON file'
    )
    
    # Model parameters
    parser.add_argument(
        '--model-type',
        type=str,
        choices=['random_forest', 'gradient_boosting'],
        help='Type of surrogate model to use'
    )
    parser.add_argument(
        '--encoding-type',
        type=str,
        choices=['label', 'onehot'],
        help='Type of categorical encoding to use'
    )
    parser.add_argument(
        '--n-samples',
        type=int,
        help='Number of synthetic samples to generate'
    )
    
    # Column specifications
    parser.add_argument(
        '--target-columns',
        nargs='+',
        help='List of target column names'
    )
    parser.add_argument(
        '--categorical-columns',
        nargs='+',
        help='List of categorical column names'
    )
    
    # Execution modes
    parser.add_argument(
        '--augment',
        action='store_true',
        help='Run pipeline with synthetic data augmentation'
    )
    parser.add_argument(
        '--validate-only',
        action='store_true',
        help='Only validate pipeline setup, do not run'
    )
    parser.add_argument(
        '--create-sample-data',
        action='store_true',
        help='Create sample datasets for testing'
    )
    parser.add_argument(
        '--create-sample-config',
        action='store_true',
        help='Create sample configuration file'
    )
    
    # Logging
    parser.add_argument(
        '--log-level',
        type=str,
        choices=['DEBUG', 'INFO', 'WARNING', 'ERROR'],
        default='INFO',
        help='Logging level'
    )
    parser.add_argument(
        '--log-file',
        type=str,
        help='Path to log file (default: console only)'
    )
    
    args = parser.parse_args()
    
    # Setup logging
    setup_logging(args.log_level, args.log_file)
    
    try:
        # Handle special modes
        if args.create_sample_data:
            logger.info("Creating sample datasets...")
            create_sample_data()
            logger.info("Sample datasets created successfully!")
            return 0
        
        if args.create_sample_config:
            logger.info("Creating sample configuration...")
            save_sample_config()
            logger.info("Sample configuration created successfully!")
            return 0
        
        # Create configuration
        config = create_config_from_args(args)
        
        # Initialize pipeline
        pipeline = SyntheticDataPipeline(config)
        
        # Validate pipeline setup
        logger.info("Validating pipeline setup...")
        validation_results = pipeline.validate_pipeline()
        
        if not validation_results['overall_valid']:
            logger.error("Pipeline validation failed:")
            for issue in validation_results['issues']:
                logger.error(f"  - {issue}")
            
            # Suggest creating sample data if data files are missing
            if not validation_results['data_paths_exist']:
                logger.info("Hint: Use --create-sample-data to create sample datasets for testing")
            
            return 1
        
        logger.info("Pipeline validation passed!")
        
        # If validate-only mode, exit here
        if args.validate_only:
            logger.info("Validation completed successfully!")
            return 0
        
        # Run pipeline
        logger.info("Starting pipeline execution...")
        
        if args.augment:
            logger.info("Running pipeline with synthetic data augmentation...")
            predictions = pipeline.run_with_synthetic_augmentation()
            logger.info(f"Pipeline with augmentation completed! Check output files.")
        else:
            logger.info("Running standard pipeline...")
            predictions = pipeline.run_pipeline()
            logger.info(f"Pipeline completed successfully!")
        
        # Print summary
        logger.info(f"Generated {len(predictions)} predictions")
        logger.info(f"Output saved to: {config.output_path}")
        logger.info(f"Columns: {list(predictions.columns)}")
        
        # Show sample predictions
        if len(predictions) > 0:
            logger.info("Sample predictions:")
            print(predictions.head().to_string(index=False))
        
        return 0
        
    except KeyboardInterrupt:
        logger.info("Pipeline execution interrupted by user")
        return 1
    except Exception as e:
        logger.error(f"Pipeline execution failed: {str(e)}")
        if args.log_level == 'DEBUG':
            import traceback
            logger.debug(traceback.format_exc())
        return 1

if __name__ == "__main__":
    sys.exit(main()) 